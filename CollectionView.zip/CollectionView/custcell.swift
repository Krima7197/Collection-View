//
//  custcell.swift
//  CollectionView
//
//  Created by TOPS on 9/7/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class custcell: UICollectionViewCell
{
    @IBOutlet weak var img: UIImageView!
    
    
}
